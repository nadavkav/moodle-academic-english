qbehaviour_deferredpenalty
=================

This is a question behaviour that simply applies multiple tries penalty
to all questions, but otherwise perfoms as normal deferred feedback. It
provides a way to penalize students that do not do assignments on time.

Copy this directory to question/behaviour/deferredpenalty in Moodle
directory. Login as admin to complete plugin installation.  Edit the quiz
settings and chose this behaviour when students should have extra penalty.

All original files are copyright Daniel Thies 2016 dthies@ccal.edu and
are licensed under the included GPL 3
