moodle-repository_mediawiki
===========================

A moodle repository to search and use content from any mediawiki installation. Based on moodle's repository_wikimedia.
