moodle--availability_coursecompleted
==============================================
Restrict module and section access based on course completion.

This availability condition makes it easy to show modules or sections only when a user
completed a course. A course certificate is a good sample, but it can also be used to close
discussion forums, hide quizes or exams when a user finished a course.